import Canvas from "./canvas.svelte";
import { canvasCodeTemplates } from "./code-templates.js";
import type { CanvasProps, ComponentDef } from "./types.js";

export { Canvas, canvasCodeTemplates };
export type { ComponentDef, CanvasProps };
export default Canvas;
