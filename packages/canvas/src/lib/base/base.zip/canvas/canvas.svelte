<script lang="ts" module>
import type { EditorComponent } from "../editor/types.ts";
import type { CanvasProps } from "./types.js";

export interface CanvasConfig extends EditorComponent<CanvasProps> {}

export const canvasConfig: CanvasConfig = {
	props: {
		components: [],
	},
	editorConfig: {
		fields: {
			components: {
				type: "text",
				label: "Components",
				description: "JSON array of component definitions",
			},
		},
	},
};
</script>

<script lang="ts">
import { cn } from "$lib/utils.js";
import { SvelteMap } from "svelte/reactivity";
import type {
	ComponentDef,
	ComponentRegistryValue,
	CanvasProps,
} from "./types.js";

import { Text } from "$lib/base/text/index.js";
import { Button } from "$lib/base/button/index.js";
import { View } from "$lib/base/view/index.js";

const componentRegistry = new SvelteMap<string, ComponentRegistryValue>();

componentRegistry.set("Box", View);
componentRegistry.set("View", View);
componentRegistry.set("Text", Text);
componentRegistry.set("Button", Button);

let {
	components = [],
	class: className = "",
	customComponents = new SvelteMap(),
	renderComponent,
	...restProps
}: CanvasProps = $props();

if (customComponents) {
	customComponents.forEach((component, name) => {
		componentRegistry.set(name, component);
	});
}
</script>

{#snippet renderChild(component: ComponentDef)}
	{#if !component || !component.type}
		<div class="canvas-error">Invalid component</div>
	{:else if componentRegistry.has(component.type)}
		{@const ComponentClass = componentRegistry.get(component.type)}
		{@const { props = {}, children = [] } = component}

		<ComponentClass {...props}>
			{#each children as child (child)}
				{@render renderChild(child)}
			{/each}
		</ComponentClass>
	{:else}
		<div class="canvas-error">
			Component type '{component.type}' not found
		</div>
	{/if}
{/snippet}

<div
	class={cn("canvas", className)}
	data-component="canvas"
	{...restProps}
>
	{#each components as component (component.id || component.type)}
		{#if renderComponent}
			{@render renderComponent(component)}
		{:else}
			{@render renderChild(component)}
		{/if}
	{/each}
</div>

<style>
	.canvas {
		position: relative;
		min-height: 1rem;
		min-width: 1rem;
	}

	.canvas-error {
		padding: 0.5rem;
		border: 0.25rem dashed rgb(220, 38, 38);
		color: rgb(220, 38, 38);
		background-color: rgba(220, 38, 38, 0.1);
		border-radius: 0.25rem;
		font-family: monospace;
		font-size: 0.875rem;
		margin: 0.25rem 0;
	}
</style>
