/** biome-ignore-all lint/suspicious/noExplicitAny: cause i wanna */
import type { Component } from "svelte";
import type { HTMLAttributes } from "svelte/elements";
import type { SvelteMap } from "svelte/reactivity";

export interface BaseProps extends HTMLAttributes<HTMLElement> {
	id?: string;
	[key: string]: any;
}

export interface ComponentDef<TProps extends BaseProps = BaseProps> {
	id?: string;
	type: string;
	props?: TProps;
	children?: ComponentDef<TProps>[];
	schema?: Record<string, any>;
}

export type RenderComponentFn = <TProps extends BaseProps = BaseProps>(
	component: ComponentDef<TProps>,
) => any;

export type ComponentRegistryValue = Component<any, any, any>;

export interface CanvasProps extends HTMLAttributes<HTMLDivElement> {
	components?: ComponentDef<BaseProps>[];
	class?: string;
	customComponents?: SvelteMap<string, ComponentRegistryValue>;
	renderComponent?: RenderComponentFn;
}

export type StudioCanvasProps = CanvasProps;
