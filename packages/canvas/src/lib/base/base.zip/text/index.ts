import Text from "./text.svelte";
import type { TextProps } from "./text.svelte";

export { Text };
export type { TextProps };
export default Text;
