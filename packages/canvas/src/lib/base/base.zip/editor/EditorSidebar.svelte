<script lang="ts">
import { browser } from "$app/environment";

import { cn } from "$lib/utils.js";
// Will be replaced by Sidebar.Group
import EditorField from "./fields/EditorField.svelte";
import { formatComponentType, isMobileDevice } from "./utils.js";
// import EditorGroup from './EditorGroup.svelte'; // This component might not be needed if using Sidebar.Group directly

// Import icons
import SettingsIcon from "@lucide/svelte/icons/settings";
import X from "@lucide/svelte/icons/x";

// Renamed to avoid conflict
// Renamed to avoid conflict

// Import new Sidebar components

import * as Button from "$lib/components/ui/button/index.js";
import * as Drawer from "$lib/components/ui/drawer/index.js";
import * as ScrollArea from "$lib/components/ui/scroll-area/index.js";
import * as Sidebar from "$lib/components/ui/sidebar/index.js";
// Import types
import type { EditorComponent, EditorSidebarProps } from "./types.js";

// Props definition
let {
	mode = $bindable("docked"), // This prop might become redundant
	selection = $bindable(undefined),
	editorConfig = $bindable({}),
	updateProperty = $bindable(() => {}),
	class: className = "",
	isDraggable = $bindable(false), // This prop might become redundant
	activePanel = $bindable("Properties"),
}: EditorSidebarProps = $props();

// Local state
let isOpen = $state(false); // For mobile drawer
let isDragging = $state(false);
let dragStartX = $state(0);
let dragStartY = $state(0);
let dragStartPosition = $state({ x: 0, y: 0 });
let sidebarPosition = $state({ x: 0, y: 0 });
let sidebarElement = $state<HTMLElement | null>(null);
let isMobile = $state(false);

// Get component config
const componentConfig = $derived(
	selection?.component?.type
		? (editorConfig[selection.component.type] as EditorComponent<object>)
		: undefined,
);

// Get component props
const componentProps = $derived(selection?.component?.props || {});

// Get field groups
const editorGroups = $derived(componentConfig?.editorConfig?.groups || {});

// Get fields
const editorFields = $derived(componentConfig?.editorConfig?.fields || {});

// Filtered groups without fields
const filteredGroups = $derived(
	Object.entries(editorGroups)
		.filter(([_, group]) => group.fields && group.fields.length > 0)
		.map(([key, group]) => ({
			name: key,
			config: group,
			fields:
				group.fields
					?.map((fieldName) => ({
						name: fieldName,
						config: editorFields[fieldName],
					}))
					.filter((field) => field.config) || [],
		}))
		.filter((group) => group.fields.length > 0),
);

// Ungrouped fields
const ungroupedFields = $derived(
	Object.entries(editorFields)
		.filter(([key]) => {
			// Check if this field is in any group
			return !Object.values(editorGroups).some((group) =>
				group.fields?.includes(key),
			);
		})
		.map(([key, field]) => ({
			name: key,
			config: field,
		})),
);

// Handle property change
function handlePropertyChange(propertyName: string, value: object) {
	if (updateProperty && selection) {
		updateProperty(selection.path, propertyName, value);
	}
}

// Determine if we should use mobile bottom sheet
$effect(() => {
	if (browser) {
		isMobile = isMobileDevice();
	}
});

// Show drawer on mobile when a component is selected and panel is 'Properties'
$effect(() => {
	if (isMobile && selection && activePanel === "Properties") {
		isOpen = true;
	} else if (isMobile && (!selection || activePanel !== "Properties")) {
		// Optionally close if selection is lost or panel changes, or manage separately
		// isOpen = false;
	}
});

// Content for Properties panel is now inlined below
</script>

{#if isMobile}
  <!-- Mobile bottom sheet for Properties panel -->
  <Drawer.Root bind:open={isOpen} snapPoints={[0.5, 0.9]}>
    <Drawer.Content class="bg-background">
      <div class="border-b px-4 py-3">
        <div class="flex items-center justify-between">
          <h2 class="text-lg font-medium">
            {activePanel === "Properties" && selection?.component
              ? formatComponentType(selection.component.type)
              : activePanel}
          </h2>
          <Button.Root
            variant="ghost"
            size="icon"
            onclick={() => (isOpen = false)}
          >
            <X class="h-4 w-4" />
          </Button.Root>
        </div>
      </div>
      <ScrollArea.Root class="h-[calc(100%-57px)]">
        {#if activePanel === "Properties"}
          {#if selection && componentConfig}
            <div class="p-4">
              {#if filteredGroups.length > 0}
                {#each filteredGroups as group}
                  <Sidebar.Group class="mb-4">
                    <Sidebar.GroupLabel
                      >{group.config.label || group.name}</Sidebar.GroupLabel
                    >
                    <Sidebar.GroupContent class="space-y-3">
                      {#each group.fields as field}
                        <EditorField
                          name={field.name}
                          config={field.config}
                          value={componentProps[field.name]}
                          onChange={(value) =>
                            handlePropertyChange(field.name, value)}
                        />
                      {/each}
                    </Sidebar.GroupContent>
                  </Sidebar.Group>
                {/each}
              {/if}

              {#if ungroupedFields.length > 0}
                <Sidebar.Group class="mb-4">
                  {#if filteredGroups.length > 0}
                    <Sidebar.GroupLabel
                      >Other Properties</Sidebar.GroupLabel
                    >
                  {/if}
                  <Sidebar.GroupContent class="space-y-3">
                    {#each ungroupedFields as field}
                      <EditorField
                        name={field.name}
                        config={field.config}
                        value={componentProps[field.name]}
                        onChange={(value) =>
                          handlePropertyChange(field.name, value)}
                      />
                    {/each}
                  </Sidebar.GroupContent>
                </Sidebar.Group>
              {/if}
            </div>
          {:else}
            <div
              class="text-muted-foreground flex h-60 flex-col items-center justify-center p-4 text-center"
            >
              <SettingsIcon class="mb-4 h-12 w-12 opacity-20" />
              <p>Select a component to edit its properties.</p>
            </div>
          {/if}
        {:else if activePanel === "Layers"}
          <div class="p-4">
            <p class="text-muted-foreground">
              Layers/Component Tree (Not Implemented)
            </p>
          </div>
        {:else if activePanel === "Components"}
          <div class="p-4">
            <p class="text-muted-foreground">
              Component Palette (Not Implemented)
            </p>
          </div>
        {:else if activePanel === "Settings"}
          <div class="p-4">
            <p class="text-muted-foreground">
              Editor Settings (Not Implemented)
            </p>
          </div>
        {/if}
        <ScrollArea.Scrollbar orientation="vertical" />
      </ScrollArea.Root>
    </Drawer.Content>
  </Drawer.Root>
{:else}
  <!-- Desktop sidebar uses Sidebar.Content directly -->
  <Sidebar.Content class={cn("flex h-full flex-col", className)}>
    <ScrollArea.Root class="flex-1">
      {#if activePanel === "Properties"}
        {#if selection && componentConfig}
          <div class="p-4">
            {#if filteredGroups.length > 0}
              {#each filteredGroups as group}
                <Sidebar.Group class="mb-4">
                  <Sidebar.GroupLabel
                    >{group.config.label || group.name}</Sidebar.GroupLabel
                  >
                  <Sidebar.GroupContent class="space-y-3">
                    {#each group.fields as field}
                      <EditorField
                        name={field.name}
                        config={field.config}
                        value={componentProps[field.name]}
                        onChange={(value) =>
                          handlePropertyChange(field.name, value)}
                      />
                    {/each}
                  </Sidebar.GroupContent>
                </Sidebar.Group>
              {/each}
            {/if}

            {#if ungroupedFields.length > 0}
              <Sidebar.Group class="mb-4">
                {#if filteredGroups.length > 0}
                  <Sidebar.GroupLabel>Other Properties</Sidebar.GroupLabel
                  >
                {/if}
                <Sidebar.GroupContent class="space-y-3">
                  {#each ungroupedFields as field}
                    <EditorField
                      name={field.name}
                      config={field.config}
                      value={componentProps[field.name]}
                      onChange={(value) =>
                        handlePropertyChange(field.name, value)}
                    />
                  {/each}
                </Sidebar.GroupContent>
              </Sidebar.Group>
            {/if}
          </div>
        {:else}
          <div
            class="text-muted-foreground flex h-60 flex-col items-center justify-center p-4 text-center"
          >
            <SettingsIcon class="mb-4 h-12 w-12 opacity-20" />
            <p>Select a component to edit its properties.</p>
          </div>
        {/if}
      {:else if activePanel === "Layers"}
        <div class="p-4">
          <p class="text-muted-foreground">
            Layers/Component Tree (Not Implemented)
          </p>
        </div>
      {:else if activePanel === "Components"}
        <div class="p-4">
          <p class="text-muted-foreground">
            Component Palette (Not Implemented)
          </p>
        </div>
      {:else if activePanel === "Settings"}
        <div class="p-4">
          <p class="text-muted-foreground">Editor Settings (Not Implemented)</p>
        </div>
      {/if}
      <ScrollArea.Scrollbar orientation="vertical" />
    </ScrollArea.Root>
  </Sidebar.Content>
{/if}

<style>
</style>
