<script lang="ts">
import type { ComponentDef } from "$lib/base/canvas/types.js";
import { cn } from "$lib/utils.js";
import { formatComponentType } from "./utils.js";

let {
	component,
	isSelected = false,
	isHovered = false,
	onClick,
	onHover,
	onLeave,
	onContextMenu,
	children,
}: {
	component: ComponentDef;
	isSelected?: boolean;
	isHovered?: boolean;
	onClick?: (e: MouseEvent) => void;
	onHover?: () => void;
	onLeave?: () => void;
	onContextMenu?: (e: MouseEvent) => void;
	children?: any;
} = $props();

// Generate a display name for the component
const componentName = $derived(formatComponentType(component.type));
</script>

<div
  class={cn("editor-component-highlight", {
    "editor-component-selected": isSelected,
    "editor-component-hovered": isHovered && !isSelected,
  })}
  data-component-id={component.id}
  data-component-type={component.type}
  role="button"
  tabindex="0"
  onclick={onClick}
  onmouseenter={onHover}
  onmouseleave={onLeave}
  oncontextmenu={onContextMenu}
  onkeydown={(e) => e.key === "Enter" && onClick?.(new MouseEvent("click"))}
>
  {#if isHovered || isSelected}
    <div class="editor-component-label">
      {componentName}
      {#if component.props?.id || component.id}
        <span class="editor-component-id"
          >#{component.props?.id || component.id}</span
        >
      {/if}
    </div>
  {/if}

  {@render children?.()}
</div>

<style>
  .editor-component-highlight {
    position: relative;
    min-height: 5px;
    min-width: 5px;
    width: fit-content;
    height: fit-content;
  }

  .editor-component-hovered {
    outline: 1px dashed var(--primary);
    outline-offset: 1px;
  }

  .editor-component-selected {
    outline: 2px solid var(--primary);
    outline-offset: 1px;
  }

  .editor-component-label {
    position: absolute;
    top: -22px;
    left: 0;
    font-size: 10px;
    background-color: var(--primary);
    color: var(--primary-foreground);
    padding: 2px 6px;
    border-radius: 3px 3px 0 0;
    z-index: 10;
    pointer-events: none;
    white-space: nowrap;
    max-width: 200px;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .editor-component-id {
    opacity: 0.7;
    margin-left: 4px;
  }
</style>
