<script lang="ts">
import ChevronDownIcon from "@lucide/svelte/icons/chevron-down";
import ComponentIcon from "@lucide/svelte/icons/component"; // For Components panel
import Copy from "@lucide/svelte/icons/copy";
import Download from "@lucide/svelte/icons/download";
import Eye from "@lucide/svelte/icons/eye";
import EyeOff from "@lucide/svelte/icons/eye-off";
import LayersIcon from "@lucide/svelte/icons/layers"; // Original Layers icon for Edit mode
import ListOrderedIcon from "@lucide/svelte/icons/list-ordered"; // For Layers panel
import MoreVertical from "@lucide/svelte/icons/more-vertical";
import PanelRightIcon from "@lucide/svelte/icons/panel-right"; // New icon for sidebar trigger
import Plus from "@lucide/svelte/icons/plus";
import Redo2 from "@lucide/svelte/icons/redo-2";
import SettingsIcon from "@lucide/svelte/icons/settings"; // For Properties/Settings panels
import Trash from "@lucide/svelte/icons/trash";
// Import icons
import Undo2 from "@lucide/svelte/icons/undo-2";
import Upload from "@lucide/svelte/icons/upload";
import { ViewFlex } from "$lib/base/index.js";
import * as Button from "$lib/components/ui/button/index.js";
import { Card } from "$lib/components/ui/card/index.js";
import * as DropdownMenu from "$lib/components/ui/dropdown-menu/index.js";
import { Sidebar } from "$lib/components/ui/sidebar/index.js"; // For Sidebar.Trigger
import * as Tabs from "$lib/components/ui/tabs/index.js";
import * as Tooltip from "$lib/components/ui/tooltip/index.js";
import { cn } from "$lib/utils.js";
import { getEditorContext } from "./context.js";
// Import types
import type { EditorControlsProps, EditorMode, EditorPanel } from "./types.js";

interface PanelOption {
	id: EditorPanel;
	label: string;
	icon: typeof SettingsIcon; // Using a common type for icons
}

let {
	mode,
	canUndo,
	canRedo,
	activePanel = $bindable("Properties"),
	onUndo,
	onRedo,
	onModeChange,
	onPanelChange = $bindable(() => {}),
	class: className,
}: EditorControlsProps & {
	activePanel?: EditorPanel;
	onPanelChange?: (panel: EditorPanel) => void;
} = $props();

const panelOptions: PanelOption[] = [
	{ id: "Properties", label: "Properties", icon: SettingsIcon },
	{ id: "Layers", label: "Layers", icon: ListOrderedIcon },
	{ id: "Components", label: "Components", icon: ComponentIcon },
	{ id: "Settings", label: "Settings", icon: SettingsIcon },
];

// Get editor context
const editorContext = getEditorContext();

// Toggle editor mode
function toggleMode() {
	const newMode: EditorMode = mode === "edit" ? "preview" : "edit";

	if (onModeChange) {
		onModeChange(newMode);
	}
}
</script>

<div class={cn("editor-controls border-b p-2", className)}>
  <ViewFlex class="w-full items-center justify-between">
    <div class="flex items-center gap-1">
      <Tooltip.Root>
        <Tooltip.Trigger>
          {#snippet child({ props })}
            <Button.Root
              variant="ghost"
              size="icon"
              disabled={!canUndo}
              onclick={() => onUndo?.()}
              {...props}
            >
              <Undo2 class="h-4 w-4" />
            </Button.Root>
          {/snippet}
        </Tooltip.Trigger>
        <Tooltip.Content>Undo (Ctrl+Z)</Tooltip.Content>
      </Tooltip.Root>

      <Tooltip.Root>
        <Tooltip.Trigger>
          {#snippet child({ props })}
            <Button.Root
              variant="ghost"
              size="icon"
              disabled={!canRedo}
              onclick={() => onRedo?.()}
              {...props}
            >
              <Redo2 class="h-4 w-4" />
            </Button.Root>
          {/snippet}
        </Tooltip.Trigger>
        <Tooltip.Content>Redo (Ctrl+Y)</Tooltip.Content>
      </Tooltip.Root>
    </div>

    <div class="editor-controls-section">
      <Tabs.Root value={mode} class="hidden md:block">
        <Tabs.List class="m-0 flex h-auto gap-1 bg-transparent p-0">
          <Tabs.Trigger
            value="edit"
            onclick={() => onModeChange?.("edit")}
            class="h-auto px-3 py-1.5 text-xs"
          >
            Edit
          </Tabs.Trigger>
          <Tabs.Trigger
            value="preview"
            onclick={() => onModeChange?.("preview")}
            class="h-auto px-3 py-1.5 text-xs"
          >
            Preview
          </Tabs.Trigger>
        </Tabs.List>
      </Tabs.Root>
    </div>

    <!-- Panel Selector - Desktop (Segmented Buttons) -->
    <div class="hidden items-center gap-0.5 rounded-md border p-0.5 md:flex">
      {#each panelOptions as option}
        <Tooltip.Root>
          <Tooltip.Trigger>
            {#snippet child({ props: triggerProps })}
              <Button.Root
                variant={activePanel === option.id ? "secondary" : "ghost"}
                size="sm"
                class={cn(
                  "h-auto rounded-sm px-2 py-1 text-xs",
                  activePanel === option.id && "shadow"
                )}
                onclick={() => onPanelChange(option.id)}
                {...triggerProps}
              >
                <option.icon class="mr-1.5 h-3.5 w-3.5" />
                {option.label}
              </Button.Root>
            {/snippet}
          </Tooltip.Trigger>
          <Tooltip.Content>{option.label}</Tooltip.Content>
        </Tooltip.Root>
      {/each}
    </div>

    <!-- Panel Selector - Mobile (Dropdown) -->
    <div class="md:hidden">
      <DropdownMenu.Root>
        <DropdownMenu.Trigger>
          {#snippet child({ props: triggerProps })}
            <Button.Root
              variant="outline"
              size="sm"
              class="h-auto px-2 py-1 text-xs"
              {...triggerProps}
            >
              {panelOptions.find((p) => p.id === activePanel)?.label || "Panel"}
              <ChevronDownIcon class="ml-1.5 h-3.5 w-3.5" />
            </Button.Root>
          {/snippet}
        </DropdownMenu.Trigger>
        <DropdownMenu.Content>
          {#each panelOptions as option}
            <DropdownMenu.Item onclick={() => onPanelChange(option.id)}>
              <option.icon class="mr-2 h-4 w-4" />
              <span>{option.label}</span>
            </DropdownMenu.Item>
          {/each}
        </DropdownMenu.Content>
      </DropdownMenu.Root>
    </div>

    <div class="flex items-center gap-1">
      <Tooltip.Root>
        <Tooltip.Trigger>
          {#snippet child({ props: tooltipTriggerProps })}
            <Button.Root variant="ghost" size="icon" {...tooltipTriggerProps}>
              <PanelRightIcon class="h-4 w-4" />
            </Button.Root>
          {/snippet}
        </Tooltip.Trigger>
        <Tooltip.Content>Toggle Sidebar (Ctrl+B)</Tooltip.Content>
      </Tooltip.Root>

      <DropdownMenu.Root>
        <DropdownMenu.Trigger>
          {#snippet child({ props })}
            <Button.Root variant="ghost" size="icon" {...props}>
              <MoreVertical class="h-4 w-4" />
            </Button.Root>
          {/snippet}
        </DropdownMenu.Trigger>
        <DropdownMenu.Content>
          <DropdownMenu.Group>
            <DropdownMenu.Label>Page</DropdownMenu.Label>
            <DropdownMenu.Item>
              <Download class="mr-2 h-4 w-4" />
              Export JSON
            </DropdownMenu.Item>
            <DropdownMenu.Item>
              <Upload class="mr-2 h-4 w-4" />
              Import JSON
            </DropdownMenu.Item>
          </DropdownMenu.Group>
          <DropdownMenu.Separator />
          <DropdownMenu.Group>
            <DropdownMenu.Label>Selection</DropdownMenu.Label>
            <DropdownMenu.Item disabled={!$editorContext.selection}>
              <Copy class="mr-2 h-4 w-4" />
              Copy Component
            </DropdownMenu.Item>
            <DropdownMenu.Item disabled={!$editorContext.selection}>
              <Trash class="mr-2 h-4 w-4" />
              Delete Component
            </DropdownMenu.Item>
          </DropdownMenu.Group>
        </DropdownMenu.Content>
      </DropdownMenu.Root>
    </div>
  </ViewFlex>
</div>

<style>
  .editor-controls-section {
    display: flex;
    align-items: center;
    gap: 0.5rem;
  }

  @media (max-width: 768px) {
    .editor-controls {
      padding: 0.5rem;
    }
  }
</style>
