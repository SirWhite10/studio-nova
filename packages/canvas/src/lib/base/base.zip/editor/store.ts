import type { Component } from "svelte";
import { derived, get, writable } from "svelte/store";
import type { ComponentDef } from "$lib/base/canvas/types.js";
import type {
	ComponentSelection,
	EditorHistoryEntry,
	EditorMode,
	EditorSidebarMode,
	EditorState,
} from "./types.js";

/**
 * Creates a deep clone of a component definition
 */
function cloneComponent(component: ComponentDef): ComponentDef {
	return JSON.parse(JSON.stringify(component));
}

/**
 * Creates a deep clone of component definitions array
 */
function cloneComponents(components: ComponentDef[]): ComponentDef[] {
	return JSON.parse(JSON.stringify(components));
}

/**
 * Find a component by path
 */
function findComponentByPath(
	components: ComponentDef[],
	path: string[],
): ComponentDef | undefined {
	if (!path.length) return undefined;

	let current: ComponentDef | undefined;
	let currentComponents = components;

	for (let i = 0; i < path.length; i++) {
		const index = Number.parseInt(path[i], 10);
		if (isNaN(index) || index < 0 || index >= currentComponents.length) {
			return undefined;
		}

		current = currentComponents[index];
		if (i < path.length - 1) {
			if (!current.children) return undefined;
			currentComponents = current.children;
		}
	}

	return current;
}

/**
 * Update a component property by path
 */
function updateComponentProperty(
	components: ComponentDef[],
	path: string[],
	property: string,
	value: any,
): ComponentDef[] {
	const result = cloneComponents(components);
	const component = findComponentByPath(result, path);

	if (component) {
		if (!component.props) {
			component.props = {};
		}
		component.props[property] = value;
	}

	return result;
}

/**
 * Find component path in the component tree
 */
function findComponentPath(
	components: ComponentDef[],
	targetId: string,
	currentPath: string[] = [],
): string[] | null {
	for (let i = 0; i < components.length; i++) {
		const component = components[i];
		const path = [...currentPath, i.toString()];

		if (component.id === targetId) {
			return path;
		}

		if (component.children && component.children.length > 0) {
			const childPath = findComponentPath(component.children, targetId, path);
			if (childPath) return childPath;
		}
	}

	return null;
}

/**
 * Create editor store
 */
export function createEditorStore(initialComponents: ComponentDef[] = []) {
	// Create the writable store with initial state
	const store = writable<EditorState>({
		canRedo: undefined,
		canUndo: undefined,
		mode: "edit",
		components: cloneComponents(initialComponents),
		selection: undefined,
		hoveredComponent: undefined,
		history: [
			{
				components: cloneComponents(initialComponents),
				timestamp: Date.now(),
			},
		],
		historyIndex: 0,
		sidebarMode: "docked",
		sidebarVisible: true,
		componentRegistry: {},
		isDragging: false,
	});

	// Methods to update the store
	function setMode(mode: EditorMode) {
		store.update((state) => ({ ...state, mode }));
	}

	function setSidebarMode(sidebarMode: EditorSidebarMode) {
		store.update((state) => ({ ...state, sidebarMode }));
	}

	function setSidebarVisible(sidebarVisible: boolean) {
		store.update((state) => ({ ...state, sidebarVisible }));
	}

	function setComponents(components: ComponentDef[]) {
		store.update((state) => {
			const newComponents = cloneComponents(components);
			return {
				...state,
				components: newComponents,
			};
		});
		addHistoryEntry();
	}

	function setSelection(selection?: ComponentSelection) {
		store.update((state) => ({ ...state, selection }));
	}

	function setHoveredComponent(component?: ComponentDef) {
		store.update((state) => ({ ...state, hoveredComponent: component }));
	}

	function setIsDragging(isDragging: boolean) {
		store.update((state) => ({ ...state, isDragging }));
	}

	function registerComponent(name: string, component: Component) {
		store.update((state) => {
			const registry = { ...state.componentRegistry };
			registry[name] = component;
			return {
				...state,
				componentRegistry: registry,
			};
		});
	}

	function updateProperty(path: string[], property: string, value: any) {
		store.update((state) => {
			const updatedComponents = updateComponentProperty(
				state.components,
				path,
				property,
				value,
			);
			return {
				...state,
				components: updatedComponents,
			};
		});
		addHistoryEntry();
	}

	function addHistoryEntry() {
		const state = get(store);
		const newEntry: EditorHistoryEntry = {
			components: cloneComponents(state.components),
			selection: state.selection,
			timestamp: Date.now(),
		};

		store.update((state) => {
			// Remove any future history if we're not at the end
			const newHistory = state.history.slice(0, state.historyIndex + 1);
			newHistory.push(newEntry);

			return {
				...state,
				history: newHistory,
				historyIndex: newHistory.length - 1,
			};
		});
	}

	function undo() {
		store.update((state) => {
			if (state.historyIndex <= 0) return state;

			const newIndex = state.historyIndex - 1;
			const historyEntry = state.history[newIndex];

			return {
				...state,
				historyIndex: newIndex,
				components: cloneComponents(historyEntry.components),
				selection: historyEntry.selection,
			};
		});
	}

	function redo() {
		store.update((state) => {
			if (state.historyIndex >= state.history.length - 1) return state;

			const newIndex = state.historyIndex + 1;
			const historyEntry = state.history[newIndex];

			return {
				...state,
				historyIndex: newIndex,
				components: cloneComponents(historyEntry.components),
				selection: historyEntry.selection,
			};
		});
	}

	function selectComponentById(id: string) {
		const state = get(store);
		const path = findComponentPath(state.components, id);

		if (path) {
			const component = findComponentByPath(state.components, path);
			if (component) {
				setSelection({
					component,
					path,
				});
			}
		}
	}

	function addComponent(component: ComponentDef, parentPath?: string[]) {
		store.update((state) => {
			const newComponents = cloneComponents(state.components);

			if (!parentPath || parentPath.length === 0) {
				// Add to root
				newComponents.push(component);
			} else {
				// Add to parent
				const parent = findComponentByPath(newComponents, parentPath);
				if (parent) {
					if (!parent.children) {
						parent.children = [];
					}
					parent.children.push(component);
				}
			}

			return {
				...state,
				components: newComponents,
			};
		});
		addHistoryEntry();
	}

	function deleteComponent(path: string[]) {
		if (!path.length) return;

		store.update((state) => {
			const newComponents = cloneComponents(state.components);

			if (path.length === 1) {
				// Delete from root
				const index = Number.parseInt(path[0], 10);
				if (!isNaN(index) && index >= 0 && index < newComponents.length) {
					newComponents.splice(index, 1);
				}
			} else {
				// Delete from parent
				const parentPath = path.slice(0, -1);
				const parent = findComponentByPath(newComponents, parentPath);
				if (parent && parent.children) {
					const index = Number.parseInt(path[path.length - 1], 10);
					if (!isNaN(index) && index >= 0 && index < parent.children.length) {
						parent.children.splice(index, 1);
					}
				}
			}

			return {
				...state,
				components: newComponents,
				selection: undefined,
			};
		});
		addHistoryEntry();
	}

	// Derived stores
	const canUndo = derived(store, (store) => store.historyIndex > 0);
	const canRedo = derived(
		store,
		(store) => store.historyIndex < store.history.length - 1,
	);

	return {
		subscribe: store.subscribe,
		setMode,
		setSidebarMode,
		setSidebarVisible,
		setComponents,
		setSelection,
		setHoveredComponent,
		setIsDragging,
		registerComponent,
		updateProperty,
		addHistoryEntry,
		undo,
		redo,
		selectComponentById,
		addComponent,
		deleteComponent,
		canUndo,
		canRedo,
	};
}

// Create and export the editor store
export const editorStore = createEditorStore();
