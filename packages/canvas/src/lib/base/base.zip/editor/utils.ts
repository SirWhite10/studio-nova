import { browser } from "$app/environment";
import type { ComponentDef } from "$lib/base/canvas/types.js";
import type { EditorFieldType, LinkValue } from "./types.js";

/**
 * Helper to generate a unique ID
 */
export function generateId(prefix = "comp"): string {
	return `${prefix}_${Math.random().toString(36).substring(2, 11)}`;
}

/**
 * Check if a link is internal
 */
export function isInternalLink(url: string): boolean {
	if (!url) return false;
	if (!url.startsWith("http")) return true;

	if (browser) {
		return url.startsWith(window.location.origin);
	}

	return false;
}

/**
 * Format a link value
 */
export function formatLinkValue(link: string | LinkValue): LinkValue {
	if (typeof link === "string") {
		const internal = isInternalLink(link);
		return {
			url: link,
			target: internal ? "_self" : "_blank",
			internal,
		};
	}

	return link;
}

/**
 * Safely navigate to a link
 */
export function navigateToLink(
	link: string | LinkValue,
	editorMode = "edit",
): void {
	if (!browser) return;

	const linkValue = formatLinkValue(link);

	// Don't navigate in edit mode unless it's a special editor link
	if (editorMode === "edit" && !linkValue.url.startsWith("studio://")) {
		return;
	}

	// Handle studio internal links
	if (linkValue.url.startsWith("studio://")) {
		// TODO: Implement studio internal navigation
		return;
	}

	// Handle regular links
	if (linkValue.target === "_blank") {
		window.open(linkValue.url, "_blank", "noopener,noreferrer");
	} else {
		window.location.href = linkValue.url;
	}
}

/**
 * Find the appropriate input type for a field type
 */
export function getInputTypeForField(fieldType: EditorFieldType): string {
	switch (fieldType) {
		case "number":
			return "number";
		case "boolean":
			return "checkbox";
		case "color":
			return "color";
		default:
			return "text";
	}
}

/**
 * Format a component type name for display
 */
export function formatComponentType(type: string): string {
	if (!type) return "Unknown";

	// Split by camel case and capitalize each word
	return type
		.replace(/([A-Z])/g, " $1")
		.replace(/^\w/, (c) => c.toUpperCase())
		.trim();
}

/**
 * Get the drag position of an element
 */
export function getDragPosition(element: HTMLElement): {
	x: number;
	y: number;
} {
	const style = window.getComputedStyle(element);
	const matrix = new DOMMatrix(style.transform);

	return {
		x: matrix.m41,
		y: matrix.m42,
	};
}

/**
 * Deep find component by ID
 */
export function findComponentById(
	components: ComponentDef[],
	id: string,
): ComponentDef | undefined {
	for (const component of components) {
		if (component.id === id) {
			return component;
		}

		if (component.children?.length) {
			const found = findComponentById(component.children, id);
			if (found) return found;
		}
	}

	return undefined;
}

/**
 * Check if device is mobile
 */
export function isMobileDevice(): boolean {
	if (!browser) return false;

	return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(
		navigator.userAgent,
	);
}

/**
 * Handle touch or mouse event for position
 */
export function getEventPosition(event: MouseEvent | TouchEvent): {
	clientX: number;
	clientY: number;
} {
	if ("touches" in event) {
		return {
			clientX: event.touches[0].clientX,
			clientY: event.touches[0].clientY,
		};
	}

	return {
		clientX: event.clientX,
		clientY: event.clientY,
	};
}
