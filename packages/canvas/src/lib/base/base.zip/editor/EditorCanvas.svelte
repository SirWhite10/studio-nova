<script lang="ts">
// Import icons
import Trash from "@lucide/svelte/icons/trash";
import { onMount } from "svelte";
import { SvelteMap } from "svelte/reactivity";
import { get } from "svelte/store";
import { browser } from "$app/environment";
import type { ComponentDef } from "$lib/base/canvas/types.js";
import { cn } from "$lib/utils.js";
import Canvas from "../canvas/index.ts";
import { getEditorContext } from "./context.js";
import EditorComponentHighlight from "./EditorComponentHighlight.svelte";
import type { EditorCanvasProps } from "./types.js";

let {
	components = [],
	mode = "edit",
	selection = undefined,
	onSelect = undefined,
	onHover = undefined,
	componentRegistry = new SvelteMap(),
	renderComponent = undefined,
	class: className = "",
}: EditorCanvasProps = $props();

// Local state
let hoveredComponent = $state<ComponentDef | undefined>(undefined);
let contextMenuComponent = $state<ComponentDef | undefined>(undefined);
let contextMenuPosition = $state({ x: 0, y: 0 });
let canvasElement = $state<HTMLElement | undefined>(undefined);

// Handle component selection
function handleComponentSelect(component: ComponentDef, path: string[]) {
	if (onSelect) {
		onSelect({ component, path });
	}
}

// Handle component hover
function handleComponentHover(component: ComponentDef | undefined) {
	hoveredComponent = component;

	if (onHover) {
		onHover(component);
	}
}

// Handle context menu
function handleContextMenu(
	event: MouseEvent,
	component: ComponentDef,
	path: string[],
) {
	event.preventDefault();

	contextMenuComponent = component;
	contextMenuPosition = { x: event.clientX, y: event.clientY };

	// Also select the component
	handleComponentSelect(component, path);
}

// Close context menu
function closeContextMenu() {
	contextMenuComponent = undefined;
}

// Handle canvas click to deselect
function handleCanvasClick(event: MouseEvent) {
	// Only handle clicks directly on the canvas, not on components
	if (event.target === canvasElement) {
		if (onSelect) {
			// Create a null selection to deselect
			onSelect(null as any); // Type casting as any to bypass type check
		}
	}
}

// Add canvas click handler on mount
onMount(() => {
	if (browser && canvasElement) {
		canvasElement.addEventListener("click", handleCanvasClick);
	}

	return () => {
		if (browser && canvasElement) {
			canvasElement.removeEventListener("click", handleCanvasClick);
		}
	};
});

const context = getEditorContext();
const editorState = get(context);
</script>

{#snippet renderComponentSnippetForChildren(component: ComponentDef)}
  {@render renderComponent?.(component)}
{/snippet}

{#snippet renderEditorComponentSnippet(component: ComponentDef)}
  {@const renderedComponent = renderComponent
    ? renderComponent(component)
    : undefined}
  {@const isSelected = selection?.component?.id === component.id}
  {@const isHovered = hoveredComponent?.id === component.id}
  {@const path = ["0"]}

  {#if mode === "edit"}
    <EditorComponentHighlight
      {component}
      {isSelected}
      {isHovered}
      onClick={(e: MouseEvent) => {
        e.stopPropagation();
        handleComponentSelect(component, path);
      }}
      onHover={() => handleComponentHover(component)}
      onLeave={() => handleComponentHover(undefined)}
      onContextMenu={(e: MouseEvent) => handleContextMenu(e, component, path)}
    >
      {#if !component || !component.type}
        <!-- Invalid component -->
        <div class="canvas-error">Invalid component</div>
      {:else if componentRegistry.has(component.type)}
        {@const ComponentClass = componentRegistry.get(component.type)}
        {@const { props = {}, children = [] } = component}

        <ComponentClass {...props}>
          {#each children as child (child)}
            {#if renderComponent}
              {@render renderComponent(child)}
            {/if}
          {/each}
        </ComponentClass>
      {:else}
        <!-- Component type not found in registry -->
        <div class="canvas-error">
          Component type '{component.type}' not found
        </div>
      {/if}
    </EditorComponentHighlight>
  {:else if !component || !component.type}
    <!-- Invalid component -->
    <div class="studio-component-error">Invalid component</div>
  {:else if componentRegistry.has(component.type)}
    {@const ComponentClass = componentRegistry.get(component.type)}
    {@const { props = {}, children = [] } = component}

    <ComponentClass {...props}>
      {#each children as child (child)}
        {#if renderComponent}
          {@render renderComponent(child)}
        {/if}
      {/each}
    </ComponentClass>
  {:else}
    <!-- Component type not found in registry -->
    <div class="studio-component-error">
      Component type '{component.type}' not found
    </div>
  {/if}
{/snippet}

<div
  class={cn("editor-canvas", className, {
    "editor-canvas-preview": mode === "preview",
  })}
  bind:this={canvasElement}
>
  <Canvas
    {components}
    customComponents={componentRegistry}
    renderComponent={renderEditorComponentSnippet}
  />

  {#if contextMenuComponent}
    <div
      class="editor-context-menu"
      style="position: fixed; left: {contextMenuPosition.x}px; top: {contextMenuPosition.y}px;"
    >
      <div class="context-menu-content">
        <button
          class="context-menu-item"
          onclick={() => {
            if (editorState.selection)
              context.deleteComponent(editorState.selection.path);
            closeContextMenu();
          }}
        >
          <Trash class="mr-2 h-4 w-4" />
          Delete
        </button>
      </div>
    </div>
  {/if}
</div>

<style>
  .editor-canvas {
    flex: 1 1 auto;
    position: relative;
    overflow: auto;
    height: 100%;
    padding: 0.5rem;
    padding-top: 1.5rem;
    background-color: var(--background);
  }

  .editor-canvas-preview {
    /* Preview mode specific styles */
    background-color: var(--background);
  }

  .editor-context-menu {
    border-radius: var(--radius);
    border: 1px solid var(--border);
    background-color: var(--background);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    padding: 0.5rem;
    z-index: 100;
  }

  .context-menu-content {
    display: flex;
    flex-direction: column;
  }

  .context-menu-item {
    display: flex;
    align-items: center;
    padding: 0.5rem 0.75rem;
    font-size: 14px;
    cursor: pointer;
    border-radius: var(--radius);
    color: var(--foreground);
    background: transparent;
    border: none;
    text-align: left;
    width: 100%;
  }

  .context-menu-item:hover {
    background-color: var(--accent);
    background-color: var(--accent);
  }
</style>
