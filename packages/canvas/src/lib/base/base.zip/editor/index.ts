// Main editor components
import StudioEditor from "./StudioEditor.svelte";
import EditorCanvas from "./EditorCanvas.svelte";
import EditorSidebar from "./EditorSidebar.svelte";
import EditorControls from "./EditorControls.svelte";
import EditorComponentHighlight from "./EditorComponentHighlight.svelte";
import EditorGroup from "./EditorGroup.svelte";

// Field components
import EditorField from "./fields/EditorField.svelte";
import TextField from "./fields/TextField.svelte";
import NumberField from "./fields/NumberField.svelte";
import BooleanField from "./fields/BooleanField.svelte";
import SelectField from "./fields/SelectField.svelte";
import ColorField from "./fields/ColorField.svelte";
import SpacingField from "./fields/SpacingField.svelte";
import SizeField from "./fields/SizeField.svelte";
import LinkField from "./fields/LinkField.svelte";
import ImageField from "./fields/ImageField.svelte";
import IconField from "./fields/IconField.svelte";

// Store and context
export { editorStore } from "./store.js";
export {
	getEditorContext,
	setEditorContext,
	selectComponent,
	hoverComponent,
	updateComponentProperty,
	isComponentSelected,
	isComponentHovered,
} from "./context.js";

// Utility functions
export {
	generateId,
	isInternalLink,
	formatLinkValue,
	navigateToLink,
	getInputTypeForField,
	formatComponentType,
	getDragPosition,
	findComponentById,
	isMobileDevice,
	getEventPosition,
} from "./utils.js";

// Code templates
export { editorCodeTemplates } from "./code-templates.js";

// Export types
export * from "./types.js";

// Export components
export {
	StudioEditor,
	EditorCanvas,
	EditorSidebar,
	EditorControls,
	EditorComponentHighlight,
	EditorGroup,
	EditorField,
	TextField,
	NumberField,
	BooleanField,
	SelectField,
	ColorField,
	SpacingField,
	SizeField,
	LinkField,
	ImageField,
	IconField,
};

export default StudioEditor;
