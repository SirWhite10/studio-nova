<script lang="ts">
import { cn } from "$lib/utils.js";
import type { EditorFieldProps, EditorFieldConfig } from "../types.js";

// Import field type components
import TextField from "./TextField.svelte";
import NumberField from "./NumberField.svelte";
import BooleanField from "./BooleanField.svelte";
import SelectField from "./SelectField.svelte";
import ColorField from "./ColorField.svelte";
import SpacingField from "./SpacingField.svelte";
import SizeField from "./SizeField.svelte";
import LinkField from "./LinkField.svelte";
import ImageField from "./ImageField.svelte";
import IconField from "./IconField.svelte";
import RichTextField from "./RichTextField.svelte";
import ArrayField from "./ArrayField.svelte";
import ObjectField from "./ObjectField.svelte";

// Props definition
let {
	name,
	config = {
		type: "text",
		label: "",
		required: false,
	},
	value,
	onChange,
	class: className = "",
}: EditorFieldProps = $props();

// Handle value change
function handleChange(newValue: any) {
	if (onChange) {
		onChange(newValue);
	}
}

// Determine field component based on type
const fieldComponent = $derived(getFieldComponent(config.type || "text"));

// Get field component for field type
function getFieldComponent(type: string): any {
	switch (type) {
		case "text":
			return TextField;
		case "number":
			return NumberField;
		case "boolean":
			return BooleanField;
		case "select":
			return SelectField;
		case "color":
			return ColorField;
		case "spacing":
			return SpacingField;
		case "size":
			return SizeField;
		case "link":
			return LinkField;
		case "image":
			return ImageField;
		case "icon":
			return IconField;
		case "richtext":
			return RichTextField;
		case "array":
			return ArrayField;
		case "object":
			return ObjectField;
		default:
			return TextField;
	}
}
</script>

<div class={cn("editor-field", className)}>
  {#if fieldComponent}
    {@const Component = fieldComponent}
    <Component {name} {config} {value} onChange={handleChange} />
  {:else}
    <div class="editor-field-error">
      Unknown field type: {config?.type}
    </div>
  {/if}
</div>

<style>
  .editor-field {
    margin-bottom: 0.5rem;
  }

  .editor-field-error {
    padding: 0.5rem;
    border: 1px dashed var(--destructive);
    color: var(--destructive);
    font-size: 0.875rem;
    border-radius: var(--radius);
  }
</style>
