<script lang="ts">
import ComponentIcon from "@lucide/svelte/icons/component"; // Using generic component icon
import LayersIcon from "@lucide/svelte/icons/layers";
import ListIcon from "@lucide/svelte/icons/list-ordered"; // For Layers/Tree view
// Icons for the new sidebar menu
import SettingsIcon from "@lucide/svelte/icons/settings";
import { getContext, onDestroy, onMount, setContext, tick } from "svelte"; // Added setContext, getContext
import { SvelteMap } from "svelte/reactivity";
import { browser } from "$app/environment";
import type { ComponentDef } from "$lib/base/canvas/types.js";
import * as Sidebar from "$lib/components/ui/sidebar/index.js";
import { cn } from "$lib/utils.js";
import ViewFlex from "../view-flex/index.js";
import { setEditorContext as setAppEditorContext } from "./context.js"; // Renamed to avoid conflict
// Import components
import EditorCanvas from "./EditorCanvas.svelte";
import EditorControls from "./EditorControls.svelte";
import EditorSidebar from "./EditorSidebar.svelte";
import { editorStore } from "./store.js";
// Import types
import type {
	ComponentSelection,
	EditorComponent,
	EditorMode,
	EditorPanel,
	EditorProps,
	EditorSidebarMode,
} from "./types.js"; // Added EditorPanel
import { isMobileDevice } from "./utils.js";

let {
	components = $bindable([]),
	mode = $bindable("edit"),
	sidebarMode = $bindable("docked"),
	onChange,
	onModeChange,
	componentRegistry = $bindable(undefined),
	editorConfig = $bindable(undefined),
	renderComponent,
	class: className,
}: EditorProps = $props();

// Convert componentRegistry to SvelteMap
const registryMap = new SvelteMap(Object.entries(componentRegistry || {}));

// Local state
let isMobile = $state(false);
let activePanel = $state<EditorPanel>("Properties");
let isSidebarOpen = $state(true); // Default to open on desktop

// Initialize the store and app editor context
const store = setAppEditorContext(editorStore);

// Provide isMobile via context for scn_components like sidebar
const IS_MOBILE_CONTEXT_KEY = "isMobile"; // Or a Symbol if preferred and known by consumer
setContext(IS_MOBILE_CONTEXT_KEY, () => isMobile);

// Set initial components and mode
$effect.pre(() => {
	store.setComponents(components || []);
	store.setMode(mode || "edit");
});

// Sync sidebarOpen with store.sidebarVisible
// This allows the Sidebar.Trigger to control the store's visibility state
// And also allows external changes to store.sidebarVisible to control the sidebar
$effect(() => {
	isSidebarOpen = $store.sidebarVisible;
});

$effect(() => {
	store.setSidebarVisible(isSidebarOpen);
});

// Setup sidebar display mode based on props and device
$effect(() => {
	if (sidebarMode === "auto") {
		store.setSidebarMode(isMobile ? "hidden" : "docked"); // This might need adjustment if sidebar is controlled by isSidebarOpen
	} else {
		store.setSidebarMode(sidebarMode || "docked");
	}
});

// Register components from props
$effect(() => {
	if (componentRegistry) {
		Object.entries(componentRegistry).forEach(([name, component]) => {
			store.registerComponent(name, component);
		});
	}
});

// Watch for mode changes and call onModeChange callback
$effect(() => {
	if (onModeChange && $store.mode) {
		onModeChange($store.mode);
	}
});

// Handle component selection
function handleSelect(selection: ComponentSelection) {
	store.setSelection(selection);
}

// Handle component hover
function handleHover(component: ComponentDef | undefined) {
	store.setHoveredComponent(component);
}

// Handle keyboard shortcuts
function handleKeyDown(event: KeyboardEvent) {
	// Ignore if in an input field or contenteditable
	const target = event.target as HTMLElement;
	if (
		target.tagName === "INPUT" ||
		target.tagName === "TEXTAREA" ||
		target.getAttribute("contenteditable") === "true"
	) {
		return;
	}

	// Undo: Ctrl/Cmd + Z
	if (
		(event.ctrlKey || event.metaKey) &&
		event.key === "z" &&
		!event.shiftKey
	) {
		event.preventDefault();
		store.undo();
	}

	// Redo: Ctrl/Cmd + Shift + Z or Ctrl/Cmd + Y
	if (
		((event.ctrlKey || event.metaKey) && event.key === "z" && event.shiftKey) ||
		((event.ctrlKey || event.metaKey) && event.key === "y")
	) {
		event.preventDefault();
		store.redo();
	}

	// Delete: Delete or Backspace
	if (
		(event.key === "Delete" || event.key === "Backspace") &&
		$store.selection
	) {
		event.preventDefault();
		store.deleteComponent($store.selection.path);
	}

	// Toggle preview mode: Ctrl/Cmd + P
	if ((event.ctrlKey || event.metaKey) && event.key === "p") {
		event.preventDefault();
		store.setMode($store.mode === "edit" ? "preview" : "edit");
	}

	// Toggle sidebar: Ctrl/Cmd + B
	if ((event.ctrlKey || event.metaKey) && event.key === "b") {
		event.preventDefault();
		store.setSidebarVisible(!$store.sidebarVisible);
	}
}

// Check if device is mobile on mount
onMount(() => {
	if (browser) {
		isMobile = isMobileDevice();

		// Add keyboard shortcut listener
		window.addEventListener("keydown", handleKeyDown);
	}
});

onDestroy(() => {
	if (browser) {
		// Remove keyboard shortcut listener
		window.removeEventListener("keydown", handleKeyDown);
	}
});
</script>

<Sidebar.SidebarProvider>
  <div class={cn("studio-editor", className)} data-mode={$store.mode}>
    <div class="studio-editor-toolbar">
      <EditorControls
        mode={$store.mode}
        canUndo={$store.canUndo}
        canRedo={$store.canRedo}
        {activePanel}
        onUndo={() => store.undo()}
        onRedo={() => store.redo()}
        onModeChange={(newMode) => store.setMode(newMode)}
        onPanelChange={(newPanel) => (activePanel = newPanel)}
      />
    </div>

    <ViewFlex class="relative">
      <div class="studio-editor-body">
        <EditorCanvas
          components={$store.components as any}
          mode={$store.mode as any}
          selection={$store.selection as any}
          onSelect={handleSelect as any}
          onHover={handleHover as any}
          componentRegistry={registryMap}
          renderComponent={renderComponent as any}
        />
      </div>
      {#if $store.mode === "edit"}
        <Sidebar.Root
          class="hidden md:flex"
          side="right"
          variant="sidebar"
          collapsible="icon"
          data-state={isSidebarOpen ? "open" : "closed"}
          aria-hidden={!isSidebarOpen}
        >
          <EditorSidebar
            {activePanel}
            mode={$store.mode as any}
            selection={$store.selection as any}
            {editorConfig}
            updateProperty={(path, property, value) => {
              console.log("updateProperty", path, property, value);
              store.addHistoryEntry();
              store.updateProperty(path, property, value);
            }}
          />
        </Sidebar.Root>
      {/if}
    </ViewFlex>
  </div>
</Sidebar.SidebarProvider>

<style>
  .studio-editor {
    display: flex;
    flex-direction: column;
    height: 100%;
    width: 100%;
    position: relative;
    overflow: hidden;
    background-color: var(--color-background);
    color: var(--foreground);
  }

  .studio-editor-toolbar {
    /* background-color: var(--card); */
    z-index: 10;
  }

  .studio-editor-body {
    flex: 1 1 auto;
    display: flex;
    overflow: hidden;
    position: relative;
  }
</style>
