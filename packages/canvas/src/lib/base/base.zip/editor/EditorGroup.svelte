<script lang="ts">
import { cn } from "$lib/utils.js";
import * as Accordion  from "$lib/components/ui/accordion/index.js";
import EditorField from "./fields/EditorField.svelte";

// Import types
import type { EditorGroupProps, EditorFieldConfig } from "./types.js";

// Props definition
let {
	name,
	config,
	fieldsConfig,
	values = {},
	onChange,
	class: className = "",
}: EditorGroupProps = $props();

// Fields defined in this group
const groupFields = $derived(
	config.fields
		?.map((fieldName) => ({
			name: fieldName,
			config: fieldsConfig[fieldName] as EditorFieldConfig,
		}))
		.filter((field) => field.config) || [],
);

// Handle property change
function handlePropertyChange(propertyName: string, value: any) {
	if (onChange) {
		onChange(propertyName, value);
	}
}
</script>

<Accordion.Item value={name} class={cn("rounded-md border", className)}>
  <Accordion.Trigger class="flex w-full items-center justify-between p-3">
    <span>{config.label || name}</span>
  </Accordion.Trigger>
  <Accordion.Content class="p-3 pt-0">
    <div class="space-y-3">
      {#each groupFields as field}
        <EditorField
          name={field.name}
          config={field.config}
          value={values[field.name]}
          onChange={(value) => handlePropertyChange(field.name, value)}
        />
      {/each}
    </div>
  </Accordion.Content>
</Accordion.Item>
